# Contributing to Geotechnical World 🌍

Thank you for considering contributing to Geotechnical World!