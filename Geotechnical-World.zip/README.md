# Geotechnical World 🌍

Geotechnical World is a global hub for knowledge on **geotechnics, GIS, Remote Sensing, and environmental solutions**.
